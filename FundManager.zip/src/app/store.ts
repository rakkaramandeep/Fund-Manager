export interface IAppState {
}
export interface IAppState {
    tradeInfo: ITrade[];
}
export const INITIAL_STATE: IAppState = {
    tradeInfo: []
}
export interface ITrade {
    acc_id: string;
    amt: number;
    asset_class: string;
    broker_code: string;
    instrument_type: string;
    quantity: number;
    settlement_date: string;
    tick: string;
    trade_date: string;
    trade_id: number;
    tran_type: string;
}
export function rootReducer(state: IAppState, action): IAppState {
    switch (action.type) {
        
        case 'SET_DATA':
            state =  Object.assign({}, state, {
                tradeInfo: action.payload
            });
    }
    return state;
}