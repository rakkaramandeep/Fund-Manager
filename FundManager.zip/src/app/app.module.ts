import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AggregatedDailyTradesComponent } from './aggregated-daily-trades/aggregated-daily-trades.component';
import { CurrentTradesComponent } from './current-trades/current-trades.component';
import { TradeChartComponent } from './trade-chart/trade-chart.component';
import { NgRedux, NgReduxModule } from '@angular-redux/store';
import { IAppState, rootReducer, INITIAL_STATE } from './store';
import { ChartModule } from 'angular-highcharts';

import { TradeService } from './tradeService';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AggregatedDailyTradesComponent,
    CurrentTradesComponent,
    TradeChartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgReduxModule,
    ChartModule
  ],
  providers: [ TradeService ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor (ngRedux: NgRedux<any>) {
    ngRedux.configureStore(rootReducer, INITIAL_STATE);
  }
}
