import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentTradesComponent } from './current-trades.component';

describe('CurrentTradesComponent', () => {
  let component: CurrentTradesComponent;
  let fixture: ComponentFixture<CurrentTradesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentTradesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentTradesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
