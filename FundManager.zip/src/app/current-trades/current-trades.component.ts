import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common'
import { select } from '@angular-redux/store';
import { Observable } from 'rxjs';
import { IAppState } from '../store';

@Component({
  selector: 'app-current-trades',
  templateUrl: './current-trades.component.html',
  styleUrls: ['./current-trades.component.css']
})
export class CurrentTradesComponent implements OnInit {

  private tradeData: any;
  @select('tradeInfo') tradeData$: Observable<any>;

  constructor() { }

  ngOnInit() {
    this.tradeData$.subscribe(res => { 
      this.tradeData = res.filter((trade) => {
              return this.filterCurrentTrades(trade.trade_date);
            });
    });
  }

  filterCurrentTrades(tradeDate) {
    const currMonth = (new Date().getMonth() + 1) > 9 ? (new Date().getMonth() + 1) : '0' + (new Date().getMonth() + 1);
    const currDay = new Date().getDay() > 9 ? new Date().getDay() : '0' + new Date().getDay();
    const currYear = new Date().getFullYear().toString().slice(2);
    const toDayDate = currMonth + '/' + currDay + '/' + currYear;
    return toDayDate === tradeDate;
  }

}
