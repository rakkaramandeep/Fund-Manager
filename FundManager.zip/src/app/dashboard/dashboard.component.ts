import { Component, OnInit } from '@angular/core';
import { NgRedux, select } from '@angular-redux/store';
import { TradeService } from '../tradeService';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  constructor( private tradeService: TradeService, private ngRedux: NgRedux<any>  ) { }

  public tradeData: any;

  ngOnInit() {
    this.tradeService.getJSON()
       .subscribe(res => {
         this.tradeData = res; 
         
         this.ngRedux.dispatch({type: 'SET_DATA', payload:  this.tradeData});
       },
       error => {
         console.log(error)
       });
  }

  

}
