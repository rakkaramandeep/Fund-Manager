import { Component, OnInit } from '@angular/core';
import { NgRedux, select } from '@angular-redux/store';
import { IAppState } from '../store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-aggregated-daily-trades',
  templateUrl: './aggregated-daily-trades.component.html',
  styleUrls: ['./aggregated-daily-trades.component.css']
})
export class AggregatedDailyTradesComponent implements OnInit {

  //@select() trades:any;
  public tradeData: any;
  public jsonData: any;
  private tableHeads: any = [];
  public selectedFilter: string = '';
  private asset_class: boolean = false;
  private instrument_type: boolean = false;
  private acc_id: boolean = false;
  @select('tradeInfo') tradeData$: Observable<IAppState>;
  constructor( private ngRedux: NgRedux<any> ) { }

  ngOnInit() {
    this.tableHeads = ['Trade Id','Trade Date','Settlement Date','Asset Class','Instrument Type',
                      'Account ID','Broker Code','Amount','Transaction Type','Quantity','TICK'];                    

                      this.tradeData$.subscribe(tradeData => { 
                        this.tradeData = tradeData;
                      });
  }
  filterChanged(selFilterval, filterType) {
    filterType = !filterType;
    this.asset_class = selFilterval === 'asset_class' ? !this.asset_class : this.asset_class;
    this.instrument_type = selFilterval === 'instrument_type' ? !this.instrument_type : this.instrument_type;
    this.acc_id = selFilterval === 'acc_id' ? !this.acc_id : this.acc_id;
      let sortedArray: string[] = this.tradeData.sort((a,b) => {
        if (a[selFilterval] > b[selFilterval]) {
            return 1;
        }
    
        if (a[selFilterval] < b[selFilterval]) {
            return -1;
        }
        return 0;
      });
      this.tradeData = filterType ? sortedArray : sortedArray.reverse();
  }
}
