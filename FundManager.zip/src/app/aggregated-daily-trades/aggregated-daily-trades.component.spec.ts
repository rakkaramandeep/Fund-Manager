import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AggregatedDailyTradesComponent } from './aggregated-daily-trades.component';

describe('AggregatedDailyTradesComponent', () => {
  let component: AggregatedDailyTradesComponent;
  let fixture: ComponentFixture<AggregatedDailyTradesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AggregatedDailyTradesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AggregatedDailyTradesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
