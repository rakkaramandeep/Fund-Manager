import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { select } from '@angular-redux/store';
import { Observable } from 'rxjs';
import { IAppState } from '../store';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-trade-chart',
  templateUrl: './trade-chart.component.html',
  styleUrls: ['./trade-chart.component.css']
})
export class TradeChartComponent implements OnInit {

  @ViewChild('chartTarget') chartTarget: ElementRef;

  @select('tradeInfo') tradeData$: Observable<IAppState>;
  private tradeData:any;
  private chartData: any;
  private chart: any;
  constructor() { }

  ngOnInit() {
    var last15Days: any = this.getLast15DaysTrades();
    this.tradeData$.subscribe(tradeData => { 
      this.tradeData = tradeData;
      var x = tradeData;
      if(this.tradeData.length > 0){
        this.tradeData = this.tradeData.filter(trade => {
          return last15Days.indexOf(trade.trade_date) !== -1;
        });
        this.chartData = this.tradeData.map(trade => trade.quantity);
        this.bindChart();
      }
    });
  }
  formatDate(date){
    var dd = date.getDate();
    var mm = date.getMonth()+1;
    var yyyy = (date.getFullYear()).toString().slice(2);
    if(dd<10) {dd='0'+dd}
    if(mm<10) {mm='0'+mm}
    date = mm+'/'+dd+'/'+yyyy;
    return date
  }
  getLast15DaysTrades () {
    var result: any = [];
    for (var i=0; i<15; i++) {
        var d = new Date();
        d.setDate(d.getDate() - i);
        result.push( this.formatDate(d) )
    }
    return result
  }
  bindChart() {
    var chartDates = this.tradeData.map(trade => trade.trade_date);
    this.chart = new Chart({
    title: {
      text: 'Quantity Of Trades For The Last 15 Days'   
   },
   xAxis: {
      title: {
         text: 'Trade Id\'s'
      },
      categories: this.tradeData.map(trade => trade.trade_id)
   },
   yAxis: {
      title: {
         text: 'Quantity of Trades'
      }
   },   
   legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0
   },

   series: [
      {
        type: 'line',
        name: 'Trade Line',
        data: this.tradeData.map(trade => trade.quantity)

      }
    ],
    tooltip: {
      backgroundColor: '#FCFFC5',
      borderColor: 'black',
      borderRadius: 10,
      borderWidth: 2,
      formatter: function() {
        var i = this.series.data.indexOf( this.point );
        return 'The Quantity for  trade id: <b>' + this.x + '</b> is <b>' + this.y + '</b>, on <b>' + chartDates[i] + '</b>';
      }
    },
  });
  }

}
