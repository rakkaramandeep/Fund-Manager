import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { NgRedux, select } from '@angular-redux/store';

@Injectable()
export class TradeService{

    constructor(private http: HttpClient, private ngRedux: NgRedux<any>) {
    }

    public getJSON(): Observable<any> {
        this.ngRedux.dispatch({type: 'REMOVE_ALL_TODOS'});
        return this.http.get("../assets/tradesData.json");
    }
}