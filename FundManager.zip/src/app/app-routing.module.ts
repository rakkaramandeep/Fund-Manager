import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { AggregatedDailyTradesComponent } from 'src/app/aggregated-daily-trades/aggregated-daily-trades.component';
import { CurrentTradesComponent } from 'src/app/current-trades/current-trades.component';
import { TradeChartComponent } from 'src/app/trade-chart/trade-chart.component';

const routes: Routes = [
  { path: '', 
    component: DashboardComponent,
    children: [
      {
        path: '',
        redirectTo: 'trades',
        pathMatch: 'full'
      },
      { 
        path: 'trades',
        component: AggregatedDailyTradesComponent 
      },
      { 
        path: 'today-trades',
        component: CurrentTradesComponent
      },
      { 
        path: 'trade-chart',
        component: TradeChartComponent
      }
      ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
